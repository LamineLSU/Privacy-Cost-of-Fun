#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include "prioque.h"

#define NUM_READY_QUEUES 3

typedef struct ProcessBehavior {
  unsigned long cpuburst;
  unsigned long ioburst;
  int repeat;
} ProcessBehavior;

typedef struct Process {
  int pid;
  unsigned long arrival_time;
  unsigned long return_from_IO_time;
  unsigned long cpu_charge_against_quantum;
  unsigned long current_cpuburst;
  int current_q_level;  // 0..NUM_READY_QUEUES-1
  unsigned long total_cpu;      
  unsigned long total_IO;
  int good;
  int bad;
  Queue behaviors;  // queue of ProcessBehavior structs
} Process;

typedef struct ReadyQ {
  int bad;
  int good;
  int quantum;
  Queue q;
} ReadyQ;

// globals
ReadyQ Q[NUM_READY_QUEUES];
Queue IOQ;             // processes queued for I/O
Queue ArrivalQ;        // processes queued for arrival
Queue TerminatedQ;     // terminated processes
unsigned long Clock=0;
Process IdleProcess;


// initialize process descriptor for a new process.
void init_process(Process *p) {
  p->pid=0;
  p->arrival_time=0;
  p->return_from_IO_time=0;
  p->cpu_charge_against_quantum=0;
  p->current_q_level=0;
  p->total_cpu=0;
  p->total_IO=0;
  p->good=0;
  p->bad=0;
printf("here");
  init_queue(&(p->behaviors), sizeof(ProcessBehavior), 1, 0, 0);
}


// compare return from IO times for two processes
int return_from_IO_compare(void *ptr1, void *ptr2) {
  Process *p1 = (Process *)ptr1;
  Process *p2 = (Process *)ptr2;
  return (p1->return_from_IO_time - p2->return_from_IO_time);
}


// compare arrival times for two processes
int arrival_compare(void *ptr1, void *ptr2) {
  Process *p1 = (Process *)ptr1;
  Process *p2 = (Process *)ptr2;
  return(p1->arrival_time - p2->arrival_time);
}

// compare PIDs for two processes
int pid_compare(void *ptr1, void *ptr2) {
  Process *p1 = (Process *)ptr1;
  Process *p2 = (Process *)ptr2;
  return(p1->pid - p2->pid);
}


// initialize all global queues.
void init_all_queues(void) {

  // initialize TerminatedQ, ArrivalQ, IOQ;
  init_queue(&IOQ, sizeof(Process), 1, return_from_IO_compare, 0);
  init_queue(&ArrivalQ, sizeof(Process), 1, arrival_compare, 0);
  init_queue(&TerminatedQ, sizeof(Process), 1, pid_compare, 0);

  // initialize ready queues
  Q[0].good=INT_MAX;
  Q[0].bad=1;
  Q[0].quantum=10;
  init_queue(&Q[0].q, sizeof(Process), 1, 0, 0);

  Q[1].good=2;
  Q[1].bad=2;
  Q[1].quantum=30;
  init_queue(&Q[1].q, sizeof(Process), 1, 0, 0);

  Q[2].good=1;
  Q[2].bad=INT_MAX;
  Q[2].quantum=100;
  init_queue(&Q[2].q, sizeof(Process), 1, 0, 0);
}


// read all processes descriptions from standard input and populate
// the 'ArrivalQueue'.
void read_process_descriptions(void) {
  Process p;
  ProcessBehavior b;
  int pid=0, first=1;
  unsigned long arrival;

  init_process(&p);
  arrival=0;
  while (scanf("%lu", &arrival) != EOF) {
      scanf("%d %lu %lu %d",
	    &pid,
	    &b.cpuburst,
	    &b.ioburst,
	    &b.repeat);


      // GGRIII
      //      printf("READ %lu %d %lu %lu %d\n",
      //	     arrival,
      //	     pid,
      //	     b.cpuburst,
      //	     b.ioburst,
      //	     b.repeat);
      // GGRIII
      

      if (! first && p.pid != pid) {
	add_to_queue(&ArrivalQ, &p, p.arrival_time);
	init_process(&p);
      }
      p.pid=pid;
      p.arrival_time=arrival;
      first=0;
      add_to_queue(&p.behaviors, &b, 1);
  }
  add_to_queue(&ArrivalQ, &p, p.arrival_time);
}


void promotion_check(Process *p, int q_level) {

  // promotion?
  if (p->cpu_charge_against_quantum < Q[q_level].quantum) {
    p->good++;
    p->bad=0;
    if (p->good >= Q[q_level].good) {
      // promote, if possible
      p->current_q_level = (p->current_q_level > 0 ?
			    p->current_q_level - 1 : p->current_q_level);
      p->good=0;
    }
  }
}


void demotion_check(Process *p, int q_level) {

  if (p->cpu_charge_against_quantum == Q[q_level].quantum) {
    p->bad++;
    p->good=0;
    if (p->bad >= Q[q_level].bad) {
      // demote f possible
      p->current_q_level = (p->current_q_level < NUM_READY_QUEUES-1 ?
			    p->current_q_level + 1 : p->current_q_level);
      p->bad=0;
    }
  }
}


// execute the highest priority process for one clock tick. Handle
// quantum expiration, CPU burst expiration, promotion, demotion,
// process termination cases.
void execute_highest_priority_process(void) {

  int i, q_level=-1;
  Process *p;
  ProcessBehavior *b;
  static int prev_pid=-1, prev_q_level=-1;

  for (i=0; i < NUM_READY_QUEUES; i++) {
    if (! empty_queue(&Q[i].q)) {
      q_level=i;
      break;
    }
  }

  if (q_level < 0) {
    // no processes to execute, give idle process one tick
    IdleProcess.total_cpu++;
  }
  else {
    // one tick of CPU time for highest priority process
    rewind_queue(&Q[q_level].q);
    p=(Process *)pointer_to_current(&Q[q_level].q);
    rewind_queue(&p->behaviors);
    b=(ProcessBehavior *)(pointer_to_current(&p->behaviors));

    // previously executed process is tracked, to suppress excessive #
    // of RUN messages

    if (prev_pid != p->pid) {
      if (prev_pid > 0) {
	printf("QUEUED: Process %d queued at level %d at time %lu.\n",
	       prev_pid, prev_q_level+1, Clock);
      }
      printf("RUN: Process %d started execution from level %d at time %lu; wants to execute for %lu ticks.\n",
	     p->pid, p->current_q_level+1, Clock, p->current_cpuburst);
      prev_pid=p->pid;
      prev_q_level=q_level;
    }

    p->cpu_charge_against_quantum++;
    p->total_cpu++;
    p->current_cpuburst--;
    
    // evaluate CPU burst expiration, possible termination, possible
    // promotion / demotion
    if (p->current_cpuburst == 0) {
      prev_pid=-1;
      // is this the final CPU burst?  If so, process is removed from the
      // queue and terminates
      if (b->repeat == 0) {
	// process is terminating, no I/O, move to termination queue
	printf("FINISHED: Process %d finished at time %lu.\n",
	       p->pid, Clock+1);
	add_to_queue(&TerminatedQ, p, 1);
      }
      else {
	// process will do I/O
	promotion_check(p, q_level);
	// demotion here is an edge case, when CPU burst and
	// quantum expire at the same time
	demotion_check(p, q_level);
	// I/O always resets demotion counter for process
	p->bad=0;
	// time for I/O
	p->return_from_IO_time=b->ioburst+Clock;
	p->cpu_charge_against_quantum=0;
	printf("I/O: Process %d blocked for I/O at time %lu.\n",
	       p->pid, Clock+1);
	add_to_queue(&IOQ, p, p->return_from_IO_time);
      }
      delete_current(&Q[q_level].q);
    }
    // evaluate quantum expiration
    else if (p->cpu_charge_against_quantum == Q[q_level].quantum) {
      prev_pid=-1;
      // expired, do demotion check
      demotion_check(p, q_level);
      // reset quantum and add to rear of proper queue
      p->cpu_charge_against_quantum=0;
      add_to_queue(&Q[p->current_q_level].q, p, 1);
      printf("QUEUED: Process %d queued at level %d at time %lu.\n",
	     p->pid, p->current_q_level+1, Clock+1);
	// delete from front of current queue
      delete_current(&Q[q_level].q);
    }
  }
}


// returns true if there are more processes to (eventually) schedule,
// otherwise false if only the idle process remains in the system.
int processes_exist(void) {

  int i, more=0;

  for (i=0; i < NUM_READY_QUEUES && ! more; i++) {
    more = ! empty_queue(&Q[i].q);
  }

  return more ||
    ! empty_queue(&IOQ) ||
    ! empty_queue(&ArrivalQ);
}

// insert new arrivals into the highest priority ready queue at the
// proper time, with their first CPU burst set.
void queue_new_arrivals(void) {

  Process *p;
  ProcessBehavior *b;

  rewind_queue(&ArrivalQ);

  // GGRIII
  //  printf("end_of_queue for arrivalQ at clock %lu:%d\n", 
  //	 Clock,
  //	 end_of_queue(&ArrivalQ));
  //
  //  if (! end_of_queue(&ArrivalQ)) {
  //    printf("head of arrival queue arrival time: %d %lu\n",
  //	   ((Process *)pointer_to_current(&ArrivalQ))->pid,
  //	   ((Process *)pointer_to_current(&ArrivalQ))->arrival_time);
  //  }
  // GGRIII
  
  while (! end_of_queue(&ArrivalQ) && Clock ==
	 (p = (Process *)pointer_to_current(&ArrivalQ))->arrival_time) {

    rewind_queue(&p->behaviors);
    b = (ProcessBehavior *)pointer_to_current(&p->behaviors);
    p->current_cpuburst = b->cpuburst;
    add_to_queue(&Q[0].q, p, 1);
    printf("CREATE: Process %d entered the ready queue at time %lu\n",
	   p->pid,
	   Clock);
    delete_current(&ArrivalQ);
  }
}


// move processes back to their proper ready Q on completion of I/O,
// handle decrement of repeat factor for behaviors
void do_IO(void) {

  Process *p;
  ProcessBehavior *b;

  rewind_queue(&IOQ);
  while (! end_of_queue(&IOQ) && Clock ==
	 (p = (Process *)pointer_to_current(&IOQ))->return_from_IO_time) {

    rewind_queue(&p->behaviors);
    b=((ProcessBehavior *)pointer_to_current(&p->behaviors));
    p->total_IO += b->ioburst;
    // decrement repeat for current behavior--there's an additonal run
    // only for the last behavior
    b->repeat--;
    if (queue_length(&p->behaviors) > 1 && b->repeat == 0) {
      // repeat has expired and not last process behavior, so time for
      // next behavior
      delete_current(&p->behaviors);
      rewind_queue(&p->behaviors);
      b=((ProcessBehavior *)pointer_to_current(&p->behaviors));
    }
    p->current_cpuburst=b->cpuburst;
    
    add_to_queue(&Q[((Process *)pointer_to_current(&IOQ))->current_q_level].q,
		 pointer_to_current(&IOQ), 1);
    delete_current(&IOQ);

  }
}


void final_report(void) {
  Process *p;

  printf("Scheduler shutdown at time %lu.\n", Clock);
  printf("Total CPU usage for all processes scheduled:\n");
  printf("Process <<null>>:\t%lu time units.\n", IdleProcess.total_cpu);
  rewind_queue(&TerminatedQ);
  while (! end_of_queue(&TerminatedQ)) {
    printf("Process %d:\t%lu time units.\n",
	   ((Process *)pointer_to_current(&TerminatedQ))->pid,
	   ((Process *)pointer_to_current(&TerminatedQ))->total_cpu);
    next_element(&TerminatedQ);
    
  }
}
    

int main(int argc, char *argv[]) {

  init_all_queues();
  init_process(&IdleProcess);
  read_process_descriptions();

  while (processes_exist()) {
    Clock++;
    queue_new_arrivals();
    execute_highest_priority_process();
    do_IO();
  }
  
  Clock++;
  final_report();

  return 0;
}
